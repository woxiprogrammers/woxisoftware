<?php
/**
 * 	(c) king-theme.com
 */

 	king::path( 'footer' );

/*
	. change footer via theme-panel
	. location in themes/aaika/templates/footer/__file__	
*/
?>
	</div><!-- #main -->
	<?php wp_footer(); ?>
</body>
</html>