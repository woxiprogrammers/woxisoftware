<?php
/**
*	This file has been preloaded, so you can wp_enqueue_style to out in wp_head();
*/	

	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

	global $king;
	
	wp_enqueue_style('king-menu-14');
	
?>
<!--Header Layout 14: Location /templates/header/-->
<header class="header header14">
	<div class="container_fhstyle2">
	    <!-- Logo -->
	    <div class="logo2">
			<a href="<?php echo SITE_URI; ?>" id="logo14">
				<img src="<?php echo esc_url( $king->cfg['logo'] ); ?>" alt="<?php bloginfo('description'); ?>" />
			</a>    
	    </div>	
		<!-- Navigation Menu -->
	    <div class="menu_main">
	      <div class="navbar yamm navbar-default">
	          <div class="navbar-header">
	            <div class="navbar-toggle .navbar-collapse .pull-right " data-toggle="collapse" data-target="#navbar-collapse-1">
					<span><?php _e( 'Menu', 'linstar' ); ?></span>
					<button type="button"> <i class="fa fa-bars"></i></button>
	            </div>
	          </div>
	          <div id="navbar-collapse-1" class="navbar-collapse collapse pullleft">
	          		<nav><?php $king->mainmenu(); ?></nav>
	          </div>
	      </div>
	    </div>
	</div>  
</header>
<div class="clearfix margin_bottom10 margin_top_res14"></div>