jQuery(document).ready(function(){
	
	/*
	 *
	 * king_options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.nhp-opts-datepicker').datepicker();
	
});